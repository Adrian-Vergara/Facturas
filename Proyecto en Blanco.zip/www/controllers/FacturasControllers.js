/**
 * Created by Adrian on 05/05/2016.
 */
(function(){
    'use strict';

    angular.module('starter')
        .controller('FacturaController', FacturaController);

    function FacturaController($ionicHistory, $state){
        /******************DECLARACION DE VARIABLES***************************/
        var vm = this;
    };
})();
